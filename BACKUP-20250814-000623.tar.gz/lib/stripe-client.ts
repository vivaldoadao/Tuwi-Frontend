/**
 * Stripe client-side configuration
 * 
 * This file contains the Stripe configuration for client-side operations
 * using Stripe Elements and the Stripe.js library.
 */

import { loadStripe } from '@stripe/stripe-js'

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

export default stripePromise